---
title: Welcome
media_order: 'hero-bg.jpg,ea_logo2.png,ea_fin.jpg'
menu: home
redirect: home
admin:
    children_display_order: collection
background: ea_fin.jpg
bannerOpacity: '0.2'
button1Link: '#works'
button2Link: '#about'
button3Text: 'Scroll Down'
button3Link: '#about'
social:
    -
        socialIconClass: 'fa fa-facebook-square'
        socialIconText: Facebook
        socialIconLink: 'https://www.facebook.com/epsilonacademics'
    -
        socialIconClass: 'fa fa-linkedin'
        socialIconText: LinkedIn
        socialIconLink: 'https://www.linkedin.com/in/manishbalamurugan/'
    -
        socialIconClass: 'fa fa-instagram'
        socialIconText: Instagram
        socialIconLink: 'https://www.instagram.com/epsilonacademics/'
    -
        socialIconClass: 'fa fa-twitter'
        socialIconText: Twitter
        socialIconLink: 'https://twitter.com/epsilonacademic'
---


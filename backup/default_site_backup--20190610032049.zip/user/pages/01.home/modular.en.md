---
title: 'Epsilon Academics'
content:
    items: '@self.modular'
menu: Home
visible: false
admin:
    children_display_order: collection
onpage_menu: false
---


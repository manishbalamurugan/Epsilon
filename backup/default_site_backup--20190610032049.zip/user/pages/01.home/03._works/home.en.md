---
title: 'Our Visison'
media_order: 'beetle.jpg,beetle2x.jpg,bg.jpg,g-beetle.jpg,g-bicycle.jpg,g-liberty.jpg,g-lighthouse.jpg,g-minimalismo.jpg,g-salad.jpg,g-shutterbug.jpg,g-skaterboy.jpg,g-woodcraft.jpg,liberty.jpg,liberty2x.jpg,lighthouse.jpg,lighthouse2x.jpg,minimalismo.jpg,minimalismo2x.jpg,salad.jpg,salad2x.jpg,shutterbug.jpg,shutterbug2x.jpg,skaterboy.jpg,skaterboy2x.jpg,woodcraft.jpg,woodcraft2x.jpg,11895.jpg,Colorful-Minimalistic-Background.jpg,50-Beautiful-and-Minimalist-Presentation-Backgrounds-033.jpg'
menu: 'Our Vision'
redirect: 'Our Vision'
visible: true
background: 50-Beautiful-and-Minimalist-Presentation-Backgrounds-033.jpg
bannerOpacity: '0'
smallTitle: 'A Word From Our Founder'
sectionBackground: bg.jpg
bioTitle: ''
bioDescription: ''
skillsTitle: ''
portfolio:
    -
        image: g-beetle.jpg
        title: 'The beetle'
        category: 'Web Development'
        link: 'https://www.behance.net/'
        description: 'Vero molestiae sed aut natus excepturi. Et tempora numquam. Temporibus iusto quo.Unde dolorem corrupti neque nisi.'
        imageSize1: beetle.jpg
        imageSize2: beetle2x.jpg
    -
        image: g-lighthouse.jpg
        title: Lighthouse
        category: 'Web Design'
        link: 'https://www.behance.net/'
        description: 'Vero molestiae sed aut natus excepturi. Et tempora numquam. Temporibus iusto quo.Unde dolorem corrupti neque nisi.'
        imageSize1: lighthouse.jpg
        imageSize2: lighthouse2x.jpg
    -
        image: g-salad.jpg
        title: Salad
        category: Branding
        link: 'https://www.behance.net/'
        description: 'Vero molestiae sed aut natus excepturi. Et tempora numquam. Temporibus iusto quo.Unde dolorem corrupti neque nisi.'
        imageSize1: salad.jpg
        imageSize2: salad2x.jpg
    -
        image: g-woodcraft.jpg
        title: Woodcraft
        category: Branding
        link: 'https://www.behance.net/'
        description: 'Vero molestiae sed aut natus excepturi. Et tempora numquam. Temporibus iusto quo.Unde dolorem corrupti neque nisi.'
        imageSize1: woodcraft.jpg
        imageSize2: woodcraft2x.jpg
    -
        image: g-skaterboy.jpg
        title: Skaterboy
        category: 'Web Development'
        link: 'https://www.behance.net/'
        description: 'Vero molestiae sed aut natus excepturi. Et tempora numquam. Temporibus iusto quo.Unde dolorem corrupti neque nisi.'
        imageSize1: skaterboy.jpg
        imageSize2: skaterboy2x.jpg
    -
        image: g-liberty.jpg
        title: Liberty
        category: Branding
        link: 'https://www.behance.net/'
        description: 'Vero molestiae sed aut natus excepturi. Et tempora numquam. Temporibus iusto quo.Unde dolorem corrupti neque nisi.'
        imageSize1: liberty.jpg
        imageSize2: liberty2x.jpg
    -
        image: g-minimalismo.jpg
        title: Minimalismo
        category: 'Web Design'
        link: 'https://www.behance.net/'
        description: 'Vero molestiae sed aut natus excepturi. Et tempora numquam. Temporibus iusto quo.Unde dolorem corrupti neque nisi.'
        imageSize1: minimalismo.jpg
        imageSize2: minimalismo2x.jpg
    -
        image: g-shutterbug.jpg
        title: 'Lady Shutterbug'
        category: Branding
        link: 'https://www.behance.net/'
        description: 'Vero molestiae sed aut natus excepturi. Et tempora numquam. Temporibus iusto quo.Unde dolorem corrupti neque nisi.'
        imageSize1: shutterbug.jpg
        imageSize2: shutterbug2x.jpg
---

> Learning is grand adventure, and like all great adventures, learning is something that is meant to not be done alone, but together. My journey in STEM began mainly in middle school where I was first introduced to a vast amount of oppurtunities for me to grow as both a scholar and as a person under the guidance of my amazing teachers. These experiences have given me a world of oppurtunities, and I believe that everyone should have the an equal oppurtunity to explore STEM. In creating an environment where students of all ages can work together, I truly belive that we can create a community where learning is driven by the interests and passions of students who work and grow together as both scholars and people. 
> 

### Manish Balamurugan | Co-Founder and Director
 
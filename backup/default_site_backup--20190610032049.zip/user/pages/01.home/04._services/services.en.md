---
title: 'What We Do'
media_order: niche-k-12-1910px.png
menu: 'What We Do'
redirect: 'What We Do'
visible: true
services:
    -
        icon: 'fa fa-globe'
        title: 'Academic Tutoring'
        description: 'Epsilon Academics offers tutoring services for a wide variety of courses and interests. Whether the student is in need of tutoring to aid and improve their academic performance or supplement their learning in the classroom to get them ahead of the curve, Epsilon Academics provides an excellent tutoring service that is custom tailored to each student.'
    -
        icon: 'fa fa-code'
        title: 'Computer Science'
        description: 'Our commitment to fostering STEM education has lead us to continuously host free workshops in order to provide students with unique opportunities to immerse themselves within STEM. For example, we host MLH workshops targeted towards high school students to teach them a wide variety of computer science topics ranging from app development to blockchain. Additionally, we host events for students of all ages such as introductory crash courses in 3D modeling and programming languages such as Java and Python.'
    -
        icon: 'fa fa-envira'
        title: 'Standardized Test Prep'
        description: 'Regardless of a student’s age, they will always face standardized testing; from the second-grader hoping to pass the NNAT/CogAT and hoping to be placed into Advanced Academic Programs (AAP) to the high schooler hoping to conquer the SAT/ACT and aspiring towards college. Our test prep services are all taught by the high-quality instructors who are all top performing students that have taken the tests themselves and passed with flying colors.'
    -
        icon: 'fa fa-apple'
        title: Mentoring
        description: "Stress has become a part of the education culture and student life in the United States. This is due not only to the immense course loads placed on students but also because of the constant change faced by students, not only in between grades but between schools. The shift between elementary to middle school or middle to high school can be an especially tough time in a student’s learning career. The tutors at Epsilon Academics are not only educators but also mentors. In addition to helping students feel more prepared for their academic lives, tutors also act as mentors who form emotional bonds with their students and help them navigate the status quo of academic life. \r\n"
---

We specialize in mentoring and guiding students through exploring STEM subjects in Northern Virginia and the Washington Metropolitan area. From initiating and running club chapters to coaching for competitive STEM-based competitions, we do our best to inspire STEM education within our community.

In our first year, we formed a partnership with Lanier Middle School and since the launch of our program in November 2018, over 25 Fairfax High School Students have participated in academic enrichment sessions at Lanier Middle School.  We tutor students who participate in several clubs at Lanier and we have also contributed to the development of two new STEM based clubs at Lanier. We believe that the implementation of this program at our public schools would significantly improve STEM education in FCPS and provide valuable learning experiences for students of all ages.



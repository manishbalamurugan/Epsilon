---
title: 'Our Founders'
media_order: 'founders.png,manish2.jpg,bg3.jpg,jog.jpg,50-Beautiful-and-Minimalist-Presentation-Backgrounds-031.jpg,bulb-and-ballon-minimalist-wallpaper-copy.jpg,fhs.jpg,62254121_687845035004682_1618161768087945216_n.png,58602791_2234588886803883_1372990943044567040_n.png,62175104_467346623835256_6657017030387957760_n.png'
menu: 'Our Founders'
redirect: 'Our Founders'
background: 62175104_467346623835256_6657017030387957760_n.png
bannerOpacity: '0.1'
smallTitle: ''
sectionBackground: ''
bioTitle: ''
bioDescription: ''
skillsTitle: ''
---

![](jog.jpg)
> Hi! My name is Justin Ortega and I am the Co-founder and Director of EPSILON ACADEMICS.  I am currently a student at Fairfax High School in 11th grade.  I have a strong interest in STEM subjects, specifically the medical field and engineering.  In the future, I plan to study biomedical engineering.  A research project which I conducted last year was one of the factors which led me to my decision to plan to pursue BME.  The research project was conducted to determine whether harmful BPA leaches from composite resin dental fillings (one of the most commonly used dental fillings) that are not fully cured by UV light.  Although my results proved to be inconclusive, the experience helped me determine that I want to study biotechnological engineering to make a profound difference on the overwhelming medical issues plaguing our country.  To inspire other students to follow their own paths, I founded Epsilon Academics as a way for students to develop lifelong intuitive skills. One of the primary goals I have at Epsilon Academics is to give every student an opportunity to see the boundless possibilities of STEM subjects: Science, Technology, Engineering, and Math.  By utilizing a student-to-student mentoring system, students of all ages are able to benefit from our program.  I have a strong dedication for education and I hope to instill a strong dedication for education in all of our students.

![](manish2.jpg)

> My name is Manish Balamurugan, and I am the Co-Founder and Director of EPSILON ACADEMICS and current junior at Fairfax High School. My interests are mainly geared towards Computer Science and Biomedical Engineering - more specifically in the application of Aritificial Intelligence within the Medical Industry. I am currently interning in Johns Hopkins BME where I am working on a research project that is working towards using deep learning models in conjunction ultrasound technology in order to create a novel, and cost effective platform for medical imaging. STEM, more specifically Computer Science, has been a passion of mine ever since Elementary School, and these interests were further peaked in middle school, where under the guidance of my amazing teachers, I became more immersed in various aspects of STEM education. As I entered high school, I started to notice a glaring lack of STEM Oppurtunities and Inniatives within my Community, and in a sense there was a strong general disinterest in STEM disciplines in my community, due to a combination of lack of proper oppurtunites and advertisement of existing oppurutunities. These issues are what motivated us to start EPSILON Academics at the start of the 2018-2019 School Year. My vision is to create a community where students of all ages and levels can work together and support each other in their academic journeys. I believe that everyone should have access to the same oppurtunities and that's exactly what we set out to do with EPSILON.
>

---
title: Statistics
menu: stats
visible: false
stats:
    -
        statCount: '300'
        statDescription: 'Volunteer Hours'
        statIconClass: 'fa fa-circle-o-notch'
        statHighlight: '0'
    -
        statCount: '1500'
        statDescription: 'Cups of Coffee'
        statIconClass: 'fa fa-beer'
        statHighlight: '0'
    -
        statCount: '50'
        statDescription: Students
        statIconClass: 'fa fa-university'
        statHighlight: '0'
    -
        statCount: '20'
        statDescription: 'Our Team'
        statIconClass: 'fa fa-lightbulb-o'
        statHighlight: '0'
hidemenu: true
---


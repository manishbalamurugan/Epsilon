---
title: 'Our Team'
media_order: 'aashishree.jpg,bigay.jpg,dhruv beter.jpg,50-Beautiful-and-Minimalist-Presentation-Backgrounds-034.jpg'
menu: 'Our Team'
redirect: 'Our Team'
process:
    markdown: true
    twig: true
twig_first: true
never_cache_twig: true
visible: true
sectionbackground: 50-Beautiful-and-Minimalist-Presentation-Backgrounds-034.jpg
backgroundOverlay: '0.5'
testimonials:
    -
        image: 'dhruv beter.jpg'
        clientName: 'Dhruv Batra'
        position: CTO
        description: 'Hi, my name is Dhruv Batra and I am the Chief Technology Officer of EPSILON ACADEMICS. I am an aspiring engineer interested in robotics and the aerospace industry. My favorite extracurriculars wherein I participate are the VEX Robotics Club, where I have been elected co-president for three years in a row; the FIRST robotics team I helped start at my school where I was elected team captain; Science Olympiad; and the National, Science, and French Honor Societies. In my free time, I work on personal projects ranging from 3D modeling to tinkering with Arduino. Additionally, I regularly attend hackathons and am a second-degree black belt in taekwondo.'
    -
        image: bigay.jpg
        clientName: 'Rishi Shah'
        position: CMO
        description: "Hi, my name is Rishi Shah. I am the Chief Marketing Officer of EPSILON\r\nACADEMICS. I am an aspiring entrepreneur, and this is my third venture. My life goal has always been to\r\nmake a difference, and my outlet of doing so has been using entrepreneurship to solve social problems.\r\nMy business plan for my start-up idea, ConnectSports, has been recognized internationally and I am\r\nworking on putting it in the market. As an entrepreneur, I like to take risks, so I challenge myself. For\r\nexample, I invest in the stock market and write motivational songs in my free time. I am in a variety of\r\nextracurriculars at school, such as DECA, FBLA, Math Honor Society, National Honor Society, and Spanish\r\nHonor Society. In college, I want to study Business operations and Microeconomics. Currently, along\r\nwith my own startups I also work with other ventures, such as JHU Professor Jim Kyung-Soo Liew’s AVC\r\nconference and tech startup DXFactor. One day, I want to solve a large social problem and change the\r\nworld."
    -
        image: aashishree.jpg
        clientName: 'Aashish Gullanki'
        position: CFO
        description: 'Hello, my name is Aashish Gullanki and I am the Chief Financial Officer of EPSILON ACADEMICS. I am currently a junior at Fairfax High School. I aspire to become a doctor and am very interested in STEM subjects such as Biology, Chemistry, Mathematics, and Computer Science. Some extracurricular activities I participate in are Math Honor Society, where I served as Financial Officer for one year; National Honor Society, where I served as Senator for one year and am currently serving as Vice President; Science Olympiad; Science Honor Society; and the INOVA Fairfax Hospital Volunteering Service. I have also been tutoring students in various levels of math ranging from elementary school math to Algebra 2 since I was in 7th grade. In my free time, I enjoy playing the piano, which I have been playing and performing for 7 years. I really enjoy working with students of all ages and am very experienced in helping students who desire aid or enrichment.'
section:
    background: blog-03-bg.jpg
hidemenu: true
---


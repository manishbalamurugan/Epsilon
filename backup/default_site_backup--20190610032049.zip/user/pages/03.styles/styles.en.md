---
title: Styles
media_order: sample-image.jpg
menu: Styles
visible: false
button1Text: 'Latest Projects'
button1Link: '#works'
button2Text: 'Scroll Down'
button2Link: '#about'
social:
    -
        socialIconClass: 'im im-facebook'
        socialIconText: Facebook
        socialIconLink: '#'
    -
        socialIconClass: 'im im-twitter'
        socialIconText: Twitter
        socialIconLink: '#'
    -
        socialIconClass: 'im im-instagram'
        socialIconText: Instagram
        socialIconLink: '#'
    -
        socialIconClass: 'im im-behance'
        socialIconText: Behance
        socialIconLink: '#'
    -
        socialIconClass: 'im im-pinterest'
        socialIconText: Pinterest
        socialIconLink: '#'
banner_content: 'I am Jonathan Doe. I am a graphic & UI/UX designer based in Somewhere.'
---

